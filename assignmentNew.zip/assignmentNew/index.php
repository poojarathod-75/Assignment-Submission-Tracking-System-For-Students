<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <?php include './links.php';?>
</head>
<body>
    <?php include './navbar.php';?>
    <br>
    <h1 class="text-center">Sample Text</h1>
</body>
</html>